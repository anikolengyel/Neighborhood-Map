
var locations = [
    {
      location: {"lat": 47.4970, "lng": 19.0634},
      "name": "Szimpla Kert"
    },
    {
      location: {"lat": 47.501341, "lng": 19.06528},
      "name": "Instant"
    },
    {
      location: {"lat" : 47.500737, "lng" : 19.059082},
      "name": "Aker't"
    },
    {
      location: {"lat" : 47.5005917, "lng" : 19.0692819},
      "name": "Fogas haz"
    },
    {
      location: {"lat" : 47.4960738, "lng" : 19.0654356},
      "name": "Corvin Club & Roof Terrace"
    },
      {
        location: {"lat" : 47.4984, "lng" : 19.0543},
        "name": "Akvárium Klub"
      },
      {
        location: {"lat" : 47.4981634, "lng" : 19.066474200000016},
        "name" : "Füge udvar"
      }

  ]
